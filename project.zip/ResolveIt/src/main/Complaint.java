package main;

import java.time.LocalDate;
import java.util.UUID;

public class Complaint {

    // Attributes
    private String complaintId;
    private String category;
    private String description;
    private String status;           // Pending / In-Progress / Resolved
    private String dateRaised;
    private String dateResolved;
    private String studentId;
    private String managerId;

    // Constructor
    public Complaint(String category, String description, String studentId) {
        this.complaintId  = assignUniqueId();
        this.category     = category;
        this.description  = description;
        this.studentId    = studentId;
        this.status       = "Pending";
        this.dateRaised   = LocalDate.now().toString();
        this.dateResolved = null;
        this.managerId    = null;
    }

    // Method: Generate a unique complaint ID
    public String assignUniqueId() {
        return "CMP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    // Method: Update complaint status
    public void updateStatus(String newStatus) {
        this.status = newStatus;
        System.out.println("Complaint " + complaintId + " status -> " + newStatus);
    }

    // Method: Print full complaint details
    public void getComplaintDetails() {
        System.out.println("==============================");
        System.out.println("Complaint ID  : " + complaintId);
        System.out.println("Category      : " + category);
        System.out.println("Description   : " + description);
        System.out.println("Status        : " + status);
        System.out.println("Date Raised   : " + dateRaised);
        System.out.println("Date Resolved : " + (dateResolved != null ? dateResolved : "N/A"));
        System.out.println("Student ID    : " + studentId);
        System.out.println("Manager ID    : " + (managerId != null ? managerId : "Not Assigned"));
        System.out.println("==============================");
    }

    // Method: Generate a plain-text report of the complaint
    public String generateReport() {
        return String.format(
            "[REPORT] ID: %s | Category: %s | Status: %s | Raised: %s | Resolved: %s | Student: %s | Manager: %s",
            complaintId, category, status, dateRaised,
            (dateResolved != null ? dateResolved : "Pending"),
            studentId,
            (managerId != null ? managerId : "Unassigned")
        );
    }

    // Getters and Setters
    public String getComplaintId()  { return complaintId; }
    public String getCategory()     { return category; }
    public String getDescription()  { return description; }
    public String getStatus()       { return status; }
    public String getDateRaised()   { return dateRaised; }
    public String getDateResolved() { return dateResolved; }
    public String getStudentId()    { return studentId; }
    public String getManagerId()    { return managerId; }

    public void setDateResolved(String dateResolved) { this.dateResolved = dateResolved; }
    public void setManagerId(String managerId)       { this.managerId = managerId; }
}