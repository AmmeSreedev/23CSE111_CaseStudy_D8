package main;
import java.util.ArrayList;
import java.util.List;

public class Student {

	    private String studentId;
	    private String name;
	    private String email;
	    private String password;
	    private List<Complaint> complaintHistory;

	    // Constructor
	    public Student(String studentId, String name, String email, String password) {
	        this.studentId = studentId;
	        this.name = name;
	        this.email = email;
	        this.password = password;
	        this.complaintHistory = new ArrayList<>();
	    }

	    // Method: Raise a new complaint
	    public Complaint raiseComplaint(String category, String description) {
	        Complaint complaint = new Complaint(category, description, this.studentId);
	        complaintHistory.add(complaint);
	        System.out.println("Complaint raised successfully. ID: " + complaint.getComplaintId());
	        return complaint;
	    }

	    // Method: Track a specific complaint by ID
	    public void trackComplaint(String complaintId) {
	        for (Complaint c : complaintHistory) {
	            if (c.getComplaintId().equals(complaintId)) {
	                System.out.println("Complaint ID : " + c.getComplaintId());
	                System.out.println("Category     : " + c.getCategory());
	                System.out.println("Status       : " + c.getStatus());
	                System.out.println("Description  : " + c.getDescription());
	                return;
	            }
	        }
	        System.out.println("No complaint found with ID: " + complaintId);
	    }

	    // Method: View all complaints raised by this student
	    public void viewHistory() {
	        if (complaintHistory.isEmpty()) {
	            System.out.println("No complaints found for student: " + name);
	            return;
	        }
	        System.out.println("=== Complaint History for " + name + " ===");
	        for (Complaint c : complaintHistory) {
	            System.out.println("ID: " + c.getComplaintId()
	                + " | Category: " + c.getCategory()
	                + " | Status: " + c.getStatus());
	        }
	    }

	    // Getters
	    public String getStudentId() { return studentId; }
	    public String getName()      { return name; }
	    public String getEmail()     { return email; }
	    public List<Complaint> getComplaintHistory() { return complaintHistory; }
	}


