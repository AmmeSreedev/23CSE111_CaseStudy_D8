package main;

import java.util.ArrayList;
import java.util.List;

public class Manager {

    // Attributes
    private String managerId;
    private String name;
    private String department;
    private List<Complaint> assignedComplaints;

    // Constructor
    public Manager(String managerId, String name, String department) {
        this.managerId = managerId;
        this.name = name;
        this.department = department;
        this.assignedComplaints = new ArrayList<>();
    }

    // Method: Assign a complaint to this manager (called by Admin)
    public void assignComplaint(Complaint complaint) {
        assignedComplaints.add(complaint);
        complaint.setManagerId(this.managerId);
        System.out.println("Complaint " + complaint.getComplaintId()
            + " assigned to Manager " + name);
    }

    // Method: View all complaints assigned to this manager
    public void viewAssignedComplaints() {
        if (assignedComplaints.isEmpty()) {
            System.out.println("No complaints assigned to " + name);
            return;
        }
        System.out.println("=== Assigned Complaints for Manager: " + name + " ===");
        for (Complaint c : assignedComplaints) {
            System.out.println("ID: " + c.getComplaintId()
                + " | Category: " + c.getCategory()
                + " | Status: " + c.getStatus());
        }
    }

    // Method: Update the status of an assigned complaint
    public void updateStatus(String complaintId, String newStatus) {
        for (Complaint c : assignedComplaints) {
            if (c.getComplaintId().equals(complaintId)) {
                c.updateStatus(newStatus);
                System.out.println("Status of Complaint " + complaintId
                    + " updated to: " + newStatus);
                return;
            }
        }
        System.out.println("Complaint " + complaintId + " not found in assigned list.");
    }

    // Method: Resolve a complaint
    public void resolveComplaint(String complaintId) {
        for (Complaint c : assignedComplaints) {
            if (c.getComplaintId().equals(complaintId)) {
                c.updateStatus("Resolved");
                c.setDateResolved(java.time.LocalDate.now().toString());
                System.out.println("Complaint " + complaintId + " resolved by " + name);
                return;
            }
        }
        System.out.println("Complaint " + complaintId + " not found.");
    }

    // Getters
    public String getManagerId()   { return managerId; }
    public String getName()        { return name; }
    public String getDepartment()  { return department; }
    public List<Complaint> getAssignedComplaints() { return assignedComplaints; }
}