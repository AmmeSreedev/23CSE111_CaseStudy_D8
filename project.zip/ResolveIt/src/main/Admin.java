package main;
import java.util.List;
public class Admin {



	    // Attributes
	    private String adminId;
	    private String name;
	    private String email;
	    private String password;

	    // Constructor
	    public Admin(String adminId, String name, String email, String password) {
	        this.adminId = adminId;
	        this.name = name;
	        this.email = email;
	        this.password = password;
	    }

	    // Method: View all complaints in the system
	    public void viewAllComplaints(List<Complaint> allComplaints) {
	        if (allComplaints.isEmpty()) {
	            System.out.println("No complaints in the system.");
	            return;
	        }
	        System.out.println("=== All Complaints (Admin View) ===");
	        for (Complaint c : allComplaints) {
	            System.out.println("ID: " + c.getComplaintId()
	                + " | Category: " + c.getCategory()
	                + " | Status: " + c.getStatus()
	                + " | Student: " + c.getStudentId());
	        }
	    }

	    // Method: Forward a complaint to a specific manager
	    public void forwardToManager(Complaint complaint, Manager manager) {
	        manager.assignComplaint(complaint);
	        complaint.updateStatus("In-Progress");
	        System.out.println("Complaint " + complaint.getComplaintId()
	            + " forwarded to Manager: " + manager.getName()
	            + " [Dept: " + manager.getDepartment() + "]");
	    }

	    // Method: Confirm and update final resolution status
	    public void updateFinalStatus(Complaint complaint, String finalStatus) {
	        complaint.updateStatus(finalStatus);
	        System.out.println("Admin confirmed final status of Complaint "
	            + complaint.getComplaintId() + " as: " + finalStatus);
	    }

	    // Getters
	    public String getAdminId() { return adminId; }
	    public String getName()    { return name; }
	    public String getEmail()   { return email; }
	}

