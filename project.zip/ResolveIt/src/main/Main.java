package main;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        System.out.println("========================================");
        System.out.println("     RESOLVEIT - COMPLAINT MANAGEMENT   ");
        System.out.println("========================================\n");

        // -------------------------------------------------------
        // STEP 1: Create Users
        // -------------------------------------------------------
        System.out.println("--- STEP 1: Creating Users ---");

        Student student1 = new Student("S001", "Arjun Kumar", "arjun@college.edu", "pass123");
        Student student2 = new Student("S002", "Priya Nair",  "priya@college.edu", "pass456");

        Admin admin = new Admin("A001", "Dr. Ramesh", "ramesh@college.edu", "adminpass");

        Manager manager1 = new Manager("M001", "Prof. Suresh", "Hostel");
        Manager manager2 = new Manager("M002", "Prof. Meena",  "Academics");

        System.out.println("Users created: " + student1.getName()
            + ", " + student2.getName()
            + ", Admin: " + admin.getName()
            + ", Managers: " + manager1.getName() + ", " + manager2.getName());

        // -------------------------------------------------------
        // STEP 2: Students Raise Complaints
        // -------------------------------------------------------
        System.out.println("\n--- STEP 2: Students Raising Complaints ---");

        Complaint c1 = student1.raiseComplaint("Hostel", "Water supply issue in Block C since 3 days.");
        Complaint c2 = student1.raiseComplaint("Academics", "Timetable clash between two mandatory subjects.");
        Complaint c3 = student2.raiseComplaint("Hostel", "Wi-Fi not working in girls' hostel.");

        // -------------------------------------------------------
        // STEP 3: Admin Views All Complaints
        // -------------------------------------------------------
        System.out.println("\n--- STEP 3: Admin Views All Complaints ---");

        // Simulated system-wide complaint list (would come from DB in real app)
        List<Complaint> allComplaints = new ArrayList<>();
        allComplaints.add(c1);
        allComplaints.add(c2);
        allComplaints.add(c3);

        admin.viewAllComplaints(allComplaints);

        // -------------------------------------------------------
        // STEP 4: Admin Forwards Complaints to Managers
        // -------------------------------------------------------
        System.out.println("\n--- STEP 4: Admin Forwards Complaints to Managers ---");

        admin.forwardToManager(c1, manager1);   // Hostel complaint -> Hostel Manager
        admin.forwardToManager(c2, manager2);   // Academics complaint -> Academics Manager
        admin.forwardToManager(c3, manager1);   // Hostel Wi-Fi -> Hostel Manager

        // -------------------------------------------------------
        // STEP 5: Managers View Their Assigned Complaints
        // -------------------------------------------------------
        System.out.println("\n--- STEP 5: Managers View Assigned Complaints ---");

        manager1.viewAssignedComplaints();
        manager2.viewAssignedComplaints();

        // -------------------------------------------------------
        // STEP 6: Managers Update Status & Resolve Complaints
        // -------------------------------------------------------
        System.out.println("\n--- STEP 6: Managers Resolving Complaints ---");

        manager1.resolveComplaint(c1.getComplaintId());   // Resolve water issue
        manager2.updateStatus(c2.getComplaintId(), "In-Progress");  // Still working on timetable
        manager1.resolveComplaint(c3.getComplaintId());   // Resolve Wi-Fi issue

        // -------------------------------------------------------
        // STEP 7: Admin Confirms Final Status
        // -------------------------------------------------------
        System.out.println("\n--- STEP 7: Admin Confirms Final Status ---");

        admin.updateFinalStatus(c1, "Resolved");
        admin.updateFinalStatus(c3, "Resolved");
        // c2 still In-Progress, admin leaves it for now

        // -------------------------------------------------------
        // STEP 8: Students Track Their Complaints
        // -------------------------------------------------------
        System.out.println("\n--- STEP 8: Students Tracking Complaints ---");

        System.out.println("\n[Arjun tracks complaint 1:]");
        student1.trackComplaint(c1.getComplaintId());

        System.out.println("\n[Arjun tracks complaint 2:]");
        student1.trackComplaint(c2.getComplaintId());

        System.out.println("\n[Priya tracks her complaint:]");
        student2.trackComplaint(c3.getComplaintId());

        // -------------------------------------------------------
        // STEP 9: Students View Full History
        // -------------------------------------------------------
        System.out.println("\n--- STEP 9: Student Complaint History ---");

        student1.viewHistory();
        System.out.println();
        student2.viewHistory();

        // -------------------------------------------------------
        // STEP 10: Detailed Complaint Reports
        // -------------------------------------------------------
        System.out.println("\n--- STEP 10: Full Complaint Details & Reports ---");

        System.out.println("\n[Complaint 1 Full Details:]");
        c1.getComplaintDetails();

        System.out.println("\n[Complaint 2 Full Details:]");
        c2.getComplaintDetails();

        System.out.println("\n[Generated Reports:]");
        System.out.println(c1.generateReport());
        System.out.println(c2.generateReport());
        System.out.println(c3.generateReport());

        System.out.println("\n========================================");
        System.out.println("         END OF RESOLVEIT DEMO          ");
        System.out.println("========================================");
    }
}