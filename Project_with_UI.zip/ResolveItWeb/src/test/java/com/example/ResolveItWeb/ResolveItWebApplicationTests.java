package com.example.ResolveItWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResolveItWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
