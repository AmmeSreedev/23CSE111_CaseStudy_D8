package com.example.ResolveItWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResolveItWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResolveItWebApplication.class, args);
	}

}
