package com.example.ResolveItWeb;
import java.util.List;
public class Admin {



	    // Attributes
	    private String adminId;
	    private String name;
	    private String email;
	    private String password;

	    // Constructor
	    public Admin(String adminId, String name, String email, String password) {
	        this.adminId = adminId;
	        this.name = name;
	        this.email = email;
	        this.password = password;
	    }

	    // Method: View all complaints in the system
	    public List<Complaint> viewAllComplaints(List<Complaint> allComplaints) {
	        return allComplaints;
	    }

	    // Method: Forward a complaint to a specific manager
	    public void forwardToManager(Complaint complaint, Manager manager) {
	        manager.assignComplaint(complaint);
	        complaint.updateStatus("In Progress");
	    }

	   

	    // Method: Confirm and update final resolution status
	    public void updateFinalStatus(Complaint complaint, String finalStatus) {
	        complaint.updateStatus(finalStatus);
	    }

	    // Getters
	    public String getAdminId() { return adminId; }
	    public String getName()    { return name; }
	    public String getEmail()   { return email; }
	}

