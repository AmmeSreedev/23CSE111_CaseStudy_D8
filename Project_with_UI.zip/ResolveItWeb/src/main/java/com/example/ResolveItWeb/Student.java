package com.example.ResolveItWeb;
import java.util.ArrayList;
import java.util.List;

public class Student {

	    private String studentId;
	    private String name;
	    private String email;
	    private String password;
	    private List<Complaint> complaintHistory;

	    // Constructor
	    public Student(String studentId, String name, String email, String password) {
	        this.studentId = studentId;
	        this.name = name;
	        this.email = email;
	        this.password = password;
	        this.complaintHistory = new ArrayList<>();
	    }

	    // Method: Raise a new complaint
	    public Complaint raiseComplaint(String category, String description) {
	        Complaint complaint = new Complaint(category, description, this.studentId);
	        complaintHistory.add(complaint);
	        return complaint;
	    }

	    // Method: Track a specific complaint by ID
	    public Complaint trackComplaint(String complaintId) {
	        for (Complaint c : complaintHistory) {
	            if (c.getComplaintId().equals(complaintId)) {
	                return c;
	            }
	        }
	        return null;
	    }

	    // Method: View all complaints raised by this student
	    public List<Complaint> viewHistory() {
	        return complaintHistory;
	    }

	    // Getters
	    public String getStudentId() { return studentId; }
	    public String getName()      { return name; }
	    public String getEmail()     { return email; }
	    public List<Complaint> getComplaintHistory() { return complaintHistory; }
	}


