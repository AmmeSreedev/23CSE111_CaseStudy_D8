package com.example.ResolveItWeb;

import java.util.ArrayList;
import java.util.List;

public class Manager {

    // Attributes
    private String managerId;
    private String name;
    private String department;
    private List<Complaint> assignedComplaints;

    // Constructor
    public Manager(String managerId, String name, String department) {
        this.managerId = managerId;
        this.name = name;
        this.department = department;
        this.assignedComplaints = new ArrayList<>();
    }

    // Method: Assign a complaint to this manager (called by Admin)
    public void assignComplaint(Complaint complaint) {
        assignedComplaints.add(complaint);
        complaint.setManagerId(this.managerId);
    }
    // Method: View all complaints assigned to this manager
    public List<Complaint> viewAssignedComplaints() {
        return assignedComplaints;
    }

    // Method: Update the status of an assigned complaint
    public void updateStatus(String complaintId, String newStatus) {
        for (Complaint c : assignedComplaints) {
            if (c.getComplaintId().equals(complaintId)) {
                c.updateStatus(newStatus);
                return;
            }
        }
    }

    // Method: Resolve a complaint
    public void resolveComplaint(String complaintId) {
        for (Complaint c : assignedComplaints) {
            if (c.getComplaintId().equals(complaintId)) {
                c.updateStatus("Resolved");
                return;
            }
        }
    }
    // Getters
    public String getManagerId()   { return managerId; }
    public String getName()        { return name; }
    public String getDepartment()  { return department; }
    public List<Complaint> getAssignedComplaints() { return assignedComplaints; }
}