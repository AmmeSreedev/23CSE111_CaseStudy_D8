package com.example.ResolveItWeb;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class MainController {

    private List<Complaint> complaints = new ArrayList<>();

    // HOME PAGE
    @GetMapping("/")
    public String home() {
        return "home";
    }

    // STUDENT PAGE
    @GetMapping("/student")
    public String studentPage(Model model) {
        model.addAttribute("complaints", complaints);
        return "student";
    }

    // SUBMIT COMPLAINT
    @PostMapping("/submitComplaint")
    public String submit(@RequestParam String studentId,
                         @RequestParam String category,
                         @RequestParam String description) {

        Complaint c = new Complaint(category, description, studentId);
        complaints.add(c);

        return "redirect:/student";
    }

    // ADMIN PAGE
    @GetMapping("/admin")
    public String adminPage(Model model) {
        model.addAttribute("complaints", complaints);
        return "admin";
    }

    // ASSIGN MANAGER
    @PostMapping("/assign")
    public String assign(@RequestParam String id,
                         @RequestParam String managerId) {

        for (Complaint c : complaints) {
            if (c.getComplaintId().equals(id)) {
                c.setManagerId(managerId);
                c.updateStatus("In Progress");
            }
        }

        return "redirect:/admin";
    }
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String role) {

        if(role.equals("Student")) return "redirect:/student";
        if(role.equals("Admin")) return "redirect:/admin";
        if(role.equals("Manager")) return "redirect:/manager";

        return "redirect:/";
    }
    // MANAGER PAGE
    @GetMapping("/manager")
    public String managerPage(Model model) {
        model.addAttribute("complaints", complaints);
        return "manager";
    }

    // UPDATE STATUS
    @PostMapping("/updateStatus")
    public String updateStatus(@RequestParam String id,
                               @RequestParam String status) {

        for (Complaint c : complaints) {
            if (c.getComplaintId().equals(id)) {
                c.updateStatus(status);
            }
        }

        return "redirect:/manager";
    }
}